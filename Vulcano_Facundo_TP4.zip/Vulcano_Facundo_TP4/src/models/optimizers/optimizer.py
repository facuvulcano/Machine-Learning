class Optimizer():
    def update(self, params, grads):
        raise NotImplementedError("Este metodo debe ser implementado por cada optimizador.")